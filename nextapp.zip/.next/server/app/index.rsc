1:"$Sreact.fragment"
2:I[5961,["423","static/chunks/423-28a5141dab489d8f.js","177","static/chunks/app/layout-80c78bec0bc3816a.js"],"default"]
3:I[4210,["423","static/chunks/423-28a5141dab489d8f.js","177","static/chunks/app/layout-80c78bec0bc3816a.js"],"ThemeProvider"]
4:I[5955,["423","static/chunks/423-28a5141dab489d8f.js","177","static/chunks/app/layout-80c78bec0bc3816a.js"],"default"]
5:I[1540,["423","static/chunks/423-28a5141dab489d8f.js","177","static/chunks/app/layout-80c78bec0bc3816a.js"],"default"]
6:I[5244,[],""]
7:I[3866,[],""]
8:I[7033,[],"ClientPageRoot"]
9:I[3721,["592","static/chunks/c15bf2b0-2e5094ff64f4d456.js","423","static/chunks/423-28a5141dab489d8f.js","603","static/chunks/603-f8a35e7ea58760eb.js","100","static/chunks/100-8a70957f9f8d4b7d.js","594","static/chunks/594-7bafb449d1e1a8d2.js","974","static/chunks/app/page-3c1d29d393612824.js"],"default"]
c:I[6213,[],"OutletBoundary"]
e:I[6213,[],"MetadataBoundary"]
10:I[6213,[],"ViewportBoundary"]
12:I[4835,[],""]
:HL["/_next/static/media/0484562807a97172-s.p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/4c285fdca692ea22-s.p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/8888a3826f4a3af4-s.p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/b957ea75a84b6ea7-s.p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/e4af272ccee01ff0-s.p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/eafabf029ad39a43-s.p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/css/e8cad3f6e0fcc9cc.css","style"]
0:{"P":null,"b":"uNKosT6zvjL1eGl354gFS","p":"","c":["",""],"i":false,"f":[[["",{"children":["__PAGE__",{}]},"$undefined","$undefined",true],["",["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/e8cad3f6e0fcc9cc.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"en","suppressHydrationWarning":true,"children":["$","body",null,{"className":"__variable_e8ce0c __variable_51684b font-sans antialiased","children":[["$","$L2",null,{}],["$","$L3",null,{"attribute":"class","defaultTheme":"dark","enableSystem":true,"disableTransitionOnChange":true,"children":["$","$L4",null,{"children":[["$","$L5",null,{}],["$","$L6",null,{"parallelRouterKey":"children","segmentPath":["children"],"error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L7",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[],[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]]],"forbidden":"$undefined","unauthorized":"$undefined"}]]}]}]]}]}]]}],{"children":["__PAGE__",["$","$1","c",{"children":[["$","$L8",null,{"Component":"$9","searchParams":{},"params":{},"promises":["$@a","$@b"]}],null,["$","$Lc",null,{"children":"$Ld"}]]}],{},null,false]},null,false],["$","$1","h",{"children":[null,["$","$1","R5rAq5zRIGoFHJ7lyfc3T",{"children":[["$","$Le",null,{"children":"$Lf"}],["$","$L10",null,{"children":"$L11"}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}]]}],false]],"m":"$undefined","G":["$12","$undefined"],"s":false,"S":true}
a:{}
b:{}
11:[["$","meta","0",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
f:[["$","meta","0",{"charSet":"utf-8"}],["$","title","1",{"children":"StruoIndia - Leading Structural Engineering Consultancy"}],["$","meta","2",{"name":"description","content":"StruoIndia is a leading provider of structural engineering consultancy services, specializing in Structure Steel Design/Detailing, Connection Design and Analysis, and more."}],["$","meta","3",{"name":"keywords","content":"structural engineering, steel design, connection design, material take-off, engineering consultancy, StruoIndia"}],["$","link","4",{"rel":"icon","href":"/favicon.ico","type":"image/x-icon","sizes":"16x16"}]]
d:null
